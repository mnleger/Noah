package org.example.x509Receiver;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@EnableWebSecurity
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    /**
     * This method modifies the current security configuration of the service. We want to use TLS/SSL, whereas the default security is
     * CSRF (Cross-Site Request Forgery). We want to disable this in order to use SSL
     *
     * @param http the initial http security configuration already initialized
     * @throws Exception catch-all exception in case there is an error while modifying the security configuration
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        //disable CSRF and instead use the SSL configuration found in Application.java
        http.csrf().disable();
    }

}
