package org.example.x509Receiver;

import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.converter.stream.InputStreamCache;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.Certificate;

@Component
public class InboundRoutes extends RouteBuilder {

    //path to the SSL keystore
    @Value("${server.ssl.key-store}")
    public Resource keystoreResource;

    //password for the SSL keystore
    @Value("${server.ssl.key-password}")
    public String keyPassword;

    //alias of the certificate (.crt file)
    @Value("${service.cert.alias}")
    public String certAlias;

    /**
     * This method defines the Camel route in which the payload will travel. Upon receiving a message, the code under from("direct:receiveHello")
     * will be invoked.
     *
     * @throws IOException In the event of a invalid message or a dropped message, this exception will be thrown to demonstrate that
     * the request and/or response failed
     */
    @Override
    public void configure() throws IOException {
        from("direct:receiveHello")
            //log the body received (at this point, the body should be encrypted by the X509 service)
            .log(LoggingLevel.INFO, "Body before decryption: " + "${body}")
            .process(new Processor() {
                /**
                 * This method uses the private key correlating to an X509 certificate to decrypt the received payload
                 *
                 * @param exchange the exchange is the received message, including headers and the raw payload
                 * @throws Exception a catch-all exception in case there is an error in processing
                 */
                @Override
                public void process(Exchange exchange) throws Exception {
                    try {
                        //load the private key matching the certificate on the X509 service
                        KeyStore keystore = KeyStore.getInstance("JKS");
                        keystore.load(keystoreResource.getInputStream(), keyPassword.toCharArray());
                        Key key = keystore.getKey(certAlias, keyPassword.toCharArray());

                        if (key instanceof PrivateKey) {
                            //find the certificate via its alias in the keystore
                            Certificate cert = keystore.getCertificate(certAlias);
                            PublicKey publicKey = cert.getPublicKey();

                            //generate a key pair using the public key and private key
                            KeyPair keyPair = new KeyPair(publicKey, (PrivateKey) key);
                            PrivateKey privateKey = keyPair.getPrivate();

                            //initialize the decryption
                            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1PADDING");
                            cipher.init(Cipher.DECRYPT_MODE, privateKey);

                            //get the body in its current form (InputStream) and convert it to a string
                            InputStreamCache inputStreamCache = (InputStreamCache) exchange.getIn().getBody();
                            StringBuilder textBuilder = new StringBuilder();
                            try (Reader reader = new BufferedReader(new InputStreamReader
                                    (inputStreamCache, Charset.forName(StandardCharsets.UTF_8.name())))) {
                                int c;
                                while ((c = reader.read()) != -1) {
                                    textBuilder.append((char) c);
                                }
                            }
                            String body = textBuilder.toString();

                            //set the body to the decoded string form of the received body
                            exchange.getIn().setBody(cipher.doFinal(Base64.decodeBase64(body)));
                        }
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                }
            })
            //log the now decrypted body
            .log(LoggingLevel.INFO, "Body after decryption: " + "${body}")
            //create a success string and set it as the body
            .process(new SuccessProcessor());
    }
}

