package org.example.x509Receiver;

import org.apache.camel.CamelContext;
import org.apache.camel.component.micrometer.eventnotifier.MicrometerExchangeEventNotifier;
import org.apache.camel.component.micrometer.messagehistory.MicrometerMessageHistoryFactory;
import org.apache.camel.spring.boot.CamelContextConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.apache.camel.component.micrometer.routepolicy.MicrometerRoutePolicyFactory;

@Configuration
public class ApplicationConfiguration {
    //initialize the logger
    protected Logger logger = LoggerFactory.getLogger(ApplicationConfiguration.class);

    @Bean
    CamelContextConfiguration contextConfiguration() {
        return new CamelContextConfiguration() {
            /**
             * This method runs configuration steps that need to occur before the service can be fully operational
             *
             * @param camelContext the initial configuration of the Camel routes imported from the dependencies in the pom.xml file
             */
            @Override
            public void beforeApplicationStart(CamelContext camelContext) {
                camelContext.setStreamCaching(true);
                camelContext.addRoutePolicyFactory(new MicrometerRoutePolicyFactory());
                camelContext.setMessageHistoryFactory((new MicrometerMessageHistoryFactory()));
                camelContext.getManagementStrategy().addEventNotifier(new MicrometerExchangeEventNotifier());
            }

            /**
             * This method runs configuration steps that need to occur after the service is up and running
             *
             * @param camelContext the initial configuration of the Camel routes imported from the dependencies in the pom.xml file
             */
            @Override
            public void afterApplicationStart(CamelContext camelContext) {
                //log the configured components of the service
                logger.info("Components:\n");
                for (String componentName : camelContext.getComponentNames()) {
                    logger.info(componentName);
                }
                logger.info("Configuration completed.");
            }


        };
    }
}

