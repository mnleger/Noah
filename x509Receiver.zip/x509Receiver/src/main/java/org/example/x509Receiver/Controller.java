package org.example.x509Receiver;

import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.InputStream;


@RestController
public class Controller {

    //producerTemplate will invoke the Camel route in InboundRoutes.java
    @Autowired
    ProducerTemplate producerTemplate;

    /**
     * This method is invoked anytime the service receives a request at the /receive resource path. This starts the sending process, creating the
     * initial body and commencing the Camel route in InboundRoutes.java.
     *
     * @param body the incoming message from the X509 service
     */
    @RequestMapping(value = "/receive")
    public void receive(InputStream body) {
        //invoke the Camel route using the body sent from the X509 service
        String stringBody = (String) producerTemplate.requestBody("direct:receiveHello", body);
    }
}
