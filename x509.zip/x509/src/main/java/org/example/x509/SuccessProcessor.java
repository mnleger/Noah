package org.example.x509;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class SuccessProcessor implements Processor {

    /**
     * This processor sets the body to an OK string. This is so that when the response is displayed on SOAPUI,
     * we have something readable rather than an InputStream that is returned by the X509Receiver
     *
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception{
        //Set the body as a string indicating we were successful
        exchange.getIn().setBody("Success");
    }

}
