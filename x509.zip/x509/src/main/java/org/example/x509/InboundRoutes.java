package org.example.x509;

import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import java.io.*;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;


@Component
public class InboundRoutes extends RouteBuilder {

    //path of the .crt file
    @Value("${service.cert.path}")
    public Resource resource;

    //initialize the logger
    protected static Logger logger = LoggerFactory.getLogger(InboundRoutes.class);

    /**
     * This method defines the Camel route in which the payload will travel. Upon receiving a message, the code under from("direct:sendHello")
     * will be invoked.
     *
     * @throws IOException In the event of a invalid message or a dropped message, this exception will be thrown to demonstrate that
     * the request and/or response failed
     */
    @Override
    public void configure() throws IOException{

        from("direct:sendHello")
                //log the body before encryption
                .log(LoggingLevel.INFO, "Body before encryption: " + "${body}")

                .process(new Processor() {
                    /**
                     * This method uses the public key of an X509 certificate to encrypt the received payload
                     *
                     * @param exchange the exchange is the received message, including headers and the raw payload
                     * @throws Exception a catch-all exception in case there is an error in processing
                     */
                    @Override
                    public void process(Exchange exchange) throws Exception {
                        //parse the .crt file
                        CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
                        X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(resource.getInputStream());

                        //retrieve the public key of the parsed certificate
                        PublicKey pk = certificate.getPublicKey();
                        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1PADDING");

                        //encrypt the payload using the public key
                        cipher.init(Cipher.ENCRYPT_MODE, pk);
                        String body = (String) exchange.getIn().getBody();
                        exchange.getIn().setBody(Base64.encodeBase64String(cipher.doFinal(body.getBytes())));
                    }
                })
                //log the body after it has been encrypted
                .log(LoggingLevel.INFO,  "Body after encryption: " + "${body}")
                //send the newly encrypted payload to the receiving service
                .to("https://localhost:8444/receive")
                //set the body to a string saying "Success". This is used to have a readable response when testing using SOAPUI
                .process(new SuccessProcessor());
        }
}

