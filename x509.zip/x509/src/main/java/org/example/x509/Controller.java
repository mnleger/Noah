package org.example.x509;

import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    //producerTemplate will invoke the Camel route in InboundRoutes.java
    @Autowired
    ProducerTemplate producerTemplate;

    //Environment variable that is a simple hello string
    @Value("${service.testBody}")
    private String testBody;

    /**
     * This method is invoked anytime the service receives a request at the /send resource path. This starts the sending process, creating the
     * initial body and commencing the Camel route in InboundRoutes.java
     */
    @RequestMapping("/send")
    public void send()
    {
        //invoke the Camel route using the testBody as the body of the message
        String body = (String) producerTemplate.requestBody("direct:sendHello", testBody);
    }

}

