package org.example.x509;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import javax.net.ssl.HttpsURLConnection;
import java.io.PrintStream;
import java.net.URL;


@SpringBootApplication
public class Application {

    /**
     * This method sets up an https connection to the X509Receiver service and then launches the service via Spring-Boot. This main method serves as
     * the starting point for
     *
     * @param  args  command line arguments passed in when running the program
     */
    public static void main(String[] args) throws Exception{
        String https_url = "https://localhost:8444/receive";
        String content = "";
        System.setProperty("javax.net.useSystemProxies", "true");

        //Define the path and password for the JKS keystore and truststore
        System.setProperty("javax.net.ssl.keyStore", "src/main/resources/certificates/keystore.jks");
        System.setProperty("javax.net.ssl.keyStorePassword", "password");
        System.setProperty("javax.net.ssl.trustStore", "src/main/resources/certificates/keystore.jks");
        System.setProperty("javax.net.ssl.trustStorePassword", "password");

        //Define which protocols will be used in the HTTPS connection (TLSv1.2)
        System.setProperty("jdk.tls.client.protocols", "TLSv1.2");
        System.setProperty("https.protocols", "TLSv1.2");

        //Connect to the X509Receiver Service via HTTPS
        HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> { return true;});
        URL url = new URL(https_url);
        HttpsURLConnection https_con = (HttpsURLConnection) url.openConnection();
        https_con.setRequestProperty("Content-Type", "application/json");
        https_con.setRequestMethod("POST");
        https_con.setDoOutput(true);
        PrintStream ps = new PrintStream(https_con.getOutputStream());
        ps.println(content);
        ps.close();

        //Launch the service using Spring-Boot
        ApplicationContext applicationContext = SpringApplication.run(Application.class, args);

    }
}


